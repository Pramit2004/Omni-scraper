#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
#  OMNI-SCRAPER — One-Command Setup for GitHub Codespaces
#  Run: bash setup.sh
# ═══════════════════════════════════════════════════════════════

set -e

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'
BOLD='\033[1m'

echo ""
echo -e "${CYAN}${BOLD}"
echo "  ⬡  OMNI-SCRAPER SETUP"
echo "  ─────────────────────────────────────"
echo -e "${NC}"

step() { echo -e "${CYAN}▶ $1${NC}"; }
ok()   { echo -e "${GREEN}✓ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠ $1${NC}"; }

# ── Python ─────────────────────────────────────────────────────
step "Installing Python dependencies..."
pip install -r requirements.txt -q --break-system-packages 2>/dev/null || \
pip install -r requirements.txt -q
ok "Python packages installed"

# ── Playwright ─────────────────────────────────────────────────
step "Installing Playwright browsers..."
playwright install chromium --with-deps -q
ok "Playwright + Chromium ready"

# ── spaCy model ────────────────────────────────────────────────
step "Downloading spaCy NLP model..."
python -m spacy download en_core_web_sm -q 2>/dev/null || warn "spaCy model skipped (optional)"
ok "NLP model ready"

# ── Frontend ───────────────────────────────────────────────────
step "Installing frontend dependencies..."
cd frontend && npm install --silent && cd ..
ok "Frontend (React + Vite) ready"

# ── .env ───────────────────────────────────────────────────────
if [ ! -f .env ]; then
  cp .env.example .env
  warn ".env created from template — add your API keys!"
else
  ok ".env already exists"
fi

# ── Infra ──────────────────────────────────────────────────────
if command -v docker &>/dev/null; then
  step "Starting Redis + Qdrant via Docker..."
  docker compose -f infra/docker-compose.yml up -d --quiet-pull
  ok "Redis (6379) + Qdrant (6333) running"
else
  warn "Docker not found — Redis/Qdrant not started. Install Docker or configure manually."
fi

echo ""
echo -e "${GREEN}${BOLD}═══════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  ✓ SETUP COMPLETE${NC}"
echo -e "${GREEN}${BOLD}═══════════════════════════════════════${NC}"
echo ""
echo -e "${CYAN}1. Edit .env with your API keys${NC}"
echo -e "${CYAN}2. Start backend:  ${YELLOW}uvicorn backend.api.server:app --reload --port 8000${NC}"
echo -e "${CYAN}3. Start frontend: ${YELLOW}cd frontend && npm run dev${NC}"
echo -e "${CYAN}4. Open:           ${YELLOW}http://localhost:3000${NC}"
echo ""
